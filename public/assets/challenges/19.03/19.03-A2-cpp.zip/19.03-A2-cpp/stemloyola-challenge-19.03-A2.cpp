/*
 * Copyright: STEM Loyola
 * Date     : March 2019
 * ID       : 19.03-A2
 * Level    : 2 (Intermediate)
 *
 * Task     : The "numbers.txt" file contains 10,000 numbers. Jane has
 *            written the following program that displays all numbers on
 *            the screen. Your task is to improve the program so that
 *            when it is run, the program will display ONLY odd numbers
 *            and at the end display the total count of even numbers 
 *            contained in the file.
 *
 * Solved By: [Your full name and email go here]
*/

#include<iostream>  // std, cout, endl
#include<fstream>   // ifstream
#include<cstdlib>   // exit()

#define FILE_NAME "numbers.txt"
#define NUMBERS_COUNT    10000

using namespace std;

int main() {
    // Open the numbers file
    ifstream numbersFile;
    numbersFile.open (FILE_NAME);

    // Ensure the file was opened successfully
    if (numbersFile.is_open() == false) {
        cout << "Error: could not open the file \"" << FILE_NAME << "\""
             << endl << "Quitting..." << endl;

        exit(1);    // Terminate the program
    }

    // Process the numbers' file and display results
    int number;
    for(int line = 1; line <= NUMBERS_COUNT; line++) {
        numbersFile >> number;  // Read the next number from the file

        cout << line << ": " << number << endl;
    }

    // Close open resources
    numbersFile.close();

    return 0;
}
