/*
 * Copyright: STEM Loyola
 * Date     : March 2019
 * ID       : 19.03-A1
 * Level    : 1 (Beginner)
 *
 * Task     : Complete this program so that when it is run, the program will
 *            display your school, current year, your full name and the value
 *            of Pi.
 *
 * Solved By: [Your full name and email go here]
*/

#include<iostream>

using namespace std;

int main() {
    // Store the information we need in variables
    string school = "Loyola High School";
    int year = 2019;

    // Display the information to the screen
    cout << "School: " << school << endl;
    cout << "Year: " << year << endl;

    return 0;
}
