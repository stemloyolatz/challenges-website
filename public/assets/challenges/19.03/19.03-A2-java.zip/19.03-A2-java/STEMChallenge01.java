/*
 * Copyright: STEM Loyola
 * Date     : March 2019
 * ID       : 19.03-A2
 * Level    : 2 (Intermediate)
 *
 * Task     : The "numbers.txt" file contains 10,000 numbers. Jane has
 *            written the following program that displays all numbers on
 *            the screen. Your task is to improve the program so that
 *            when it is run, the program will display ONLY odd numbers
 *            and at the end display the total count of even numbers 
 *            contained in the file.
 *
 * Solved By: [Your full name and email go here]
*/

import java.io.File;
import java.util.Scanner;

class STEMChallenge01 {
    
    static final String FILE_NAME  = "numbers.txt";
    static final int NUMBERS_COUNT = 10000;
    
    public static void main(String args[]) {
        // Open the numbers file and ensure it was opened successfully
        Scanner scanner = null;

        try {
            scanner = new Scanner(new File(FILE_NAME));

        } catch (Exception e) {
            System.err.format("Error: could not open the file \"%s\"\n", FILE_NAME);
            System.err.format("Quitting...\n");

            System.exit(1);    // Terminate the program
        }

        // Process the numbers' file and display results
        int number;
        for(int line = 1; line <= NUMBERS_COUNT; line++) {
            number = scanner.nextInt();  // Read the next number from the file

            System.out.printf("%d: %d\n", line, number);
        }

        // Close open resources
        scanner.close();
    }
}
