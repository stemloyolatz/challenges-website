/*
 * Copyright: STEM Loyola
 * Date     : August 2019
 * ID       : 19.08-B2
 * Level    : 2 (Intermediate)
 *
 * Task     : In 2014, NECTA released the form four (CSEE) results in GPA and
 *            class format (Figure 2). This came after they had introduced "B+"
 *            and "E" grades during the 2013 results. Your task is to convert
 *            the results to the points and divisions format (Figure 3) that we
 *            are all familiar with and count students in each division. A text
 *            file "2014-CSEE-S0800.txt" contains the results in GPA format as
 *            shown in Figure 1. No one got division zero but we have added one
 *            division-zero results to ensure you write a complete program.
 *
 *      Note: (1) Points and divisions are calculated from the 7 best grades as
 *                shown in Figure 4 and Figure 5.
 *            (2) In order to get Division IV, a student must have at least
 *                2 Ds or 1 C. This means, for example, that 6 Es and 1 D
 *                (i.e. 41 pts) will still be Division 0.
 *
 * Solved By: <Add your name here>
 *     Email: <Add your email here>
 *     Form : <Add your form here>
 *    Stream: <Add your stream/combination here>
*/

#include<iostream>  // std, cout, endl
#include<cstdio>    // fscanf(), feof(), fopen(), fclose()
#include<cstdlib>   // exit()
#include<cstring>   // strcmp()

#define FILE_NAME "2014-CSEE-S0800.txt"

using namespace std;

int main() {
    // Open the results file using file descriptors to enable easy reading of
    // the results file using custom combination of characters and symbols
    FILE* resultsFile = fopen(FILE_NAME, "r");

    // Ensure the file was opened successfully
    if ( resultsFile == NULL ) {
        cout << "Error: could not open the file \"" << FILE_NAME << "\""
             << endl << "Quitting..." << endl;

        exit(1);    // Terminate the program
    }

    // Temporary arrays that will hold students data
    char t_id[11];
    char t_subject[15];
    char t_grade[3];
    char t_end[3];

    // Parse the results files and extract students data
    while ( !feof(resultsFile) ) {
        // Extract the student ID that contains only letter S, digits and
        // forward slash (/)
        fscanf(resultsFile, "%[Ss0-9/]", t_id);
        string id (t_id);

        // Extract gender, ignoring the space surrounding the gender character
        char gender;
        fscanf(resultsFile, " %c ", &gender);

        cout << id << " " << gender << " [ ";  // For debugging

        // Extract all available subjects
        bool isLastSubject = false;

        do {
            // Extract the next subject abbreviation. Subjects contain only the
            // uppercase letters, forward slash (/) and space
            fscanf(resultsFile, "%[A-Z/ ]", t_subject);
            string subject(t_subject);

            // Extract subject's grade. Subject and grade are separated by "-"
            // and the grade is surrounded by single quotation marks. Both
            // should be ignored
            fscanf(resultsFile, "-'%[A-Z\+]'", t_grade);
            string grade(t_grade);

            cout << grade << " ";  // For debugging

            // Check if there is another subject. Subjects are separated by
            // space. The last subject will be followed by the end of line
            fscanf(resultsFile, "%[ \n]", t_end);
            if ( strcmp(t_end, "\n") == 0 || strcmp(t_end, " \n") == 0 ) {
                isLastSubject = true;
                cout << "]" << endl;  // For debugging
            }
        } while(isLastSubject == false);
    }

    // Close open resources
    fclose(resultsFile);

    return 0;
}
