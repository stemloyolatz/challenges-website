/*
 * Copyright: STEM Loyola
 * Date     : August 2019
 * ID       : 19.08-B2
 * Level    : 2 (Intermediate)
 *
 * Task     : In 2014, NECTA released the form four (CSEE) results in GPA and
 *            class format (Figure 2). This came after they had introduced "B+"
 *            and "E" grades during the 2013 results. Your task is to convert
 *            the results to the points and divisions format (Figure 3) that we
 *            are all familiar with and count students in each division. A text
 *            file "2014-CSEE-S0800.txt" contains the results in GPA format as
 *            shown in Figure 1. No one got division zero but we have added one
 *            division-zero results to ensure you write a complete program.
 *
 *      Note: (1) Points and divisions are calculated from the 7 best grades as
 *                shown in Figure 4 and Figure 5.
 *            (2) In order to get Division IV, a student must have at least
 *                2 Ds or 1 C. This means, for example, that 6 Es and 1 D
 *                (i.e. 41 pts) will still be Division 0.
 *
 * Solved By: <Add your name here>
 *     Email: <Add your email here>
 *     Form : <Add your form here>
 *    Stream: <Add your stream/combination here>
*/

#include<iostream>  // std, cout, endl
#include<fstream>   // ifstream
#include<cstdlib>   // exit()
#include<sstream>   // stringstream

#define FILE_NAME "2014-CSEE-S0800.txt"

using namespace std;

int main() {
    // Open the wards file
    ifstream resultsFile(FILE_NAME);

    // Ensure the file was opened successfully
    if ( resultsFile.is_open() == false ) {
        cout << "Error: could not open the file \"" << FILE_NAME << "\""
             << endl << "Quitting..." << endl;

        exit(1);    // Terminate the program
    }

    // Parse the results files and extract students data
    string line;
    while ( getline(resultsFile, line) ) {
        stringstream ss(line);

        // Extract student ID and gender
        string studID, gender;
        ss >> studID >> gender;

        cout << studID << " " << gender << " [ ";    // For debugging

        // Extract all subjects and grades for the current student
        string item;
        bool isGrade = false;

        while ( getline(ss, item, '\'') ) {
            if (isGrade) cout << item << " ";   // For debugging

            isGrade = !isGrade;
        }

        cout << "]" << endl;    // For debugging
    }

    // Close open resources
    resultsFile.close();

    return 0;
}
