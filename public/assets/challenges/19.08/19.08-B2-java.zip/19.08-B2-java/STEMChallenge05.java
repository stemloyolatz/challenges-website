/*
 * Copyright: STEM Loyola
 * Date     : August 2019
 * ID       : 19.08-B2
 * Level    : 2 (Intermediate)
 *
 * Task     : In 2014, NECTA released the form four (CSEE) results in GPA and
 *            class format (Figure 2). This came after they had introduced "B+"
 *            and "E" grades during the 2013 results. Your task is to convert
 *            the results to the points and divisions format (Figure 3) that we
 *            are all familiar with and count students in each division. A text
 *            file "2014-CSEE-S0800.txt" contains the results in GPA format as
 *            shown in Figure 1. No one got division zero but we have added one
 *            division-zero results to ensure you write a complete program.
 *
 *      Note: (1) Points and divisions are calculated from the 7 best grades as
 *                shown in Figure 4 and Figure 5.
 *            (2) In order to get Division IV, a student must have at least
 *                2 Ds or 1 C. This means, for example, that 6 Es and 1 D
 *                (i.e. 41 pts) will still be Division 0.
 *
 * Solved By: <Add your name here>
 *     Email: <Add your email here>
 *     Form : <Add your form here>
 *    Stream: <Add your stream/combination here>
*/

import java.io.File;
import java.util.Scanner;

class STEMChallenge05 {
    
    static final String FILE_NAME  = "2014-CSEE-S0800.txt";
    
    public static void main(String args[]) {
        // Open the results file and ensure it was opened successfully
        Scanner resultsScanner = null;

        try {
            resultsScanner = new Scanner(new File(FILE_NAME));

        } catch (Exception e) {
            System.err.format("Error: could not open the file \"%s\"\n", FILE_NAME);
            System.err.format("Quitting...\n");

            System.exit(1);    // Terminate the program
        }

        // Process the results file
        String line;

        while ( resultsScanner.hasNextLine() ) {
            line = resultsScanner.nextLine();

            String[] items = line.split(" ", 3);
            String studID  = items[0];
            String gender  = items[1];
            String subjects = items[2];

            System.out.printf("%s %s [ ", studID, gender);    // For debugging

            String[] subjectsList = subjects.split("'");

            for ( int i = 1; i < subjectsList.length; i += 2 ) {
                System.out.printf("%s ", subjectsList[i]);    // For debugging
            }

            System.out.println("]");    // For debugging
        }

        // Close open resources
        resultsScanner.close();
    }
}
