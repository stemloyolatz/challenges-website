/*
 * Copyright: STEM Loyola
 * Date     : May 2019
 * ID       : 19.08-A2
 * Level    : 2 (Intermediate)
 *
 * Task     : Over the June holiday, Luke went to visit his grandparents living
 *            at Songambele in Dodoma. When he was few minutes from getting off
 *            the bus, he overheard one lady behind him that she was born at
 *            Songambele ward in Kagera. Luke wondered how many wards are
 *            called Songambele in Tanzania. After searching online, he found
 *            out that there are four wards in Tanzania called Songambele: in
 *            Kongwa (Dodoma), Urambo (Tabora), Kyerwa (Kagera) and Kiteto (Manyara).
 *
 *            After returning to school, Luke has been searching for ward names
 *            that have been reused for more than four times. All he could find
 *            are other ward names like Magomeni, Malolo, Mbuyuni and Mjimwema
 *            that have also been reused four times. Luke has downloaded a list
 *            of all ward names in Tanzania (almost 3,650 wards) and needs your
 *            help to find all the ward names that have been reused for more
 *            than four times.
 *
 *            Note: (1) Each ward is on its own line.
 *                  (2) Some ward names like "Arusha Chini" contain spaces.
 *
 *            Fun Fact: The most famous ward name has been reused fourteen times.
 *
 * Solved By: STEM Loyola Programming Team
*/

#include<iostream>  // std, cout, endl
#include<fstream>   // ifstream
#include<cstdlib>   // exit()
#include<algorithm> // sort()

#define FILE_NAME   "tanzania-wards.txt"
#define TOTAL_WARDS 3650   // Wards are equal or less than this in the file

using namespace std;

int main() {
    // Open the wards file
    ifstream wardsFile(FILE_NAME);

    // Ensure the file was opened successfully
    if ( wardsFile.is_open() == false ) {
        cout << "Error: could not open the file \"" << FILE_NAME << "\""
             << endl << "Quitting..." << endl;

        exit(1);    // Terminate the program
    }

    string ward;
    string wardsList [TOTAL_WARDS] = {""};
    int i = 0;

    while ( getline(wardsFile, ward) ) {
        wardsList[i++] = ward;  // Add a ward into the list
    }

    // Sort the wards
    sort(wardsList, wardsList + TOTAL_WARDS);

    // Display the wards used for more than 4 times
    string currentName = wardsList[0];
    int freq =  1;
    for ( int w = 1; w < TOTAL_WARDS; w++ ) {
        if ( wardsList[w] == currentName ) {
            freq++;
        } else {
            // Check if the name has high frequency
            if ( freq > 4 && currentName != "" )
                cout << currentName << " has been reused " << freq << " times" << endl;

            // Start tracking another name
            freq = 1;
            currentName = wardsList[w];
        }
    }

    // Close open resources
    wardsFile.close();

    return 0;
}
