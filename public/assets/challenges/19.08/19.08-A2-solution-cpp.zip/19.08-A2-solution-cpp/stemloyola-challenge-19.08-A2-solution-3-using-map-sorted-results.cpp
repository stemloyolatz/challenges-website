/*
 * Copyright: STEM Loyola
 * Date     : May 2019
 * ID       : 19.08-A2
 * Level    : 2 (Intermediate)
 *
 * Task     : Over the June holiday, Luke went to visit his grandparents living
 *            at Songambele in Dodoma. When he was few minutes from getting off
 *            the bus, he overheard one lady behind him that she was born at
 *            Songambele ward in Kagera. Luke wondered how many wards are
 *            called Songambele in Tanzania. After searching online, he found
 *            out that there are four wards in Tanzania called Songambele: in
 *            Kongwa (Dodoma), Urambo (Tabora), Kyerwa (Kagera) and Kiteto (Manyara).
 *
 *            After returning to school, Luke has been searching for ward names
 *            that have been reused for more than four times. All he could find
 *            are other ward names like Magomeni, Malolo, Mbuyuni and Mjimwema
 *            that have also been reused four times. Luke has downloaded a list
 *            of all ward names in Tanzania (almost 3,650 wards) and needs your
 *            help to find all the ward names that have been reused for more
 *            than four times.
 *
 *            Note: (1) Each ward is on its own line.
 *                  (2) Some ward names like "Arusha Chini" contain spaces.
 *
 *            Fun Fact: The most famous ward name has been reused fourteen times.
 *
 * Solved By: STEM Loyola Programming Team
*/

#include<iostream>  // std, cout, endl
#include<fstream>   // ifstream
#include<cstdlib>   // exit()
#include<map>

#define FILE_NAME "tanzania-wards.txt"

using namespace std;

int main() {
    // Open the wards file
    ifstream wardsFile(FILE_NAME);

    // Ensure the file was opened successfully
    if ( wardsFile.is_open() == false ) {
        cout << "Error: could not open the file \"" << FILE_NAME << "\""
             << endl << "Quitting..." << endl;

        exit(1);    // Terminate the program
    }

    string ward;
    map<string, int> freq;  // Tracks the frequency of each ward name

    while ( getline(wardsFile, ward) ) {
        freq[ward] = freq[ward] + 1;  // Count the frequency
    }

    // Capture the frequencies exceeding 4 and sort them. Note that a map or multimap
    // automatically sorts the list using the keys. Add "greater" function to
    // have the list sorted in descending order of the key items
    multimap<int, string, greater<int> > highFreq;
    for ( map<string, int>::iterator it = freq.begin(); it != freq.end(); it++ ) {
        if (it->second > 4)
            highFreq.insert(pair<int, string>(it->second, it->first));
    }

    for ( multimap<int, string>::iterator it = highFreq.begin(); it != highFreq.end(); it++ ) {
        cout << it->second << " has been reused " << it->first << " times" << endl;
    }

    // Close open resources
    wardsFile.close();

    return 0;
}
