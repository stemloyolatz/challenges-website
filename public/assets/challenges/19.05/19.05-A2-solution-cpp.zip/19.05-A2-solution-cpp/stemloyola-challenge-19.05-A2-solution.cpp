/*
 * Copyright: STEM Loyola
 * Date     : May 2019
 * ID       : 19.05-A2
 * Level    : 2 (Intermediate)
 *
 * Task     : As the legend goes, a mysterious list of 100,000 numbers was
 *            discovered at Nungwi (the northernmost part of Unguja island).
 *            As neither the origin nor the purpose of the numbers were ever
 *            ascertained, a Mathematics professor from the University of
 *            Dar es Salaam spent one weekend analyzing the list for any
 *            interesting information. After two days of intensive work, the
 *            professor realized that the list contains only 777 prime numbers.
 *            For unknown reasons, she called these 777 numbers as the
 *            forbidden primes.
 *            You are given the entire list of 100,000 numbers (each number on
 *            its own line) and your task is to find the largest of the
 *            forbidden primes. Extra credit shall be awarded if you can find
 *            the ten (10) largest forbidden primes from the list.
 *
 *            Note: Your program should take less than 777 seconds to find the
 *                  solution. Extra credit shall be awarded for programs that
 *                  take less than 7 seconds.
 *
 *
 * Solved By: <Full Name> - <Email Address>
 *     Class: <Form> - <Stream/Combination>
*/

#include<iostream>  // std, cout, endl
#include<fstream>   // ifstream
#include<cstdlib>   // exit()
#include<algorithm> // sort()
#include<vector>
#include<cmath>     // sqrt

#define FILE_NAME    "forbidden-list.txt"
#define TOTAL_PRIMES 10

using namespace std;

// Returns true if the number is prime and false otherwise
bool isPrime ( long long num ) {
    if ( num == 2 )
        return true;  // 2 is prime
    if ( num % 2 == 0 )
        return false;  // all other even numbers are not prime

    float limit = sqrt(num) + 1; // If x is a factor of y then x <= sqrt(y). This speeds up our program

    for ( long long n = 3; n <= limit; n += 2 ) {
        if ( num % n == 0 )
            return false;  // If a number has a factor other than 1 and itself, it is not prime
    }

    return true;
}

int main() {
    // Open the numbers file
    ifstream numbersFile(FILE_NAME);

    // Ensure the file was opened successfully
    if ( numbersFile.is_open() == false ) {
        cout << "Error: could not open the file \"" << FILE_NAME << "\""
             << endl << "Quitting..." << endl;

        exit(1);    // Terminate the program
    }

    long long num;
    vector<long long> numbersList;

    while ( numbersFile >> num ) {
        // Capture only odd numbers or 2. Those are the only possible primes
        if ( num % 2 == 1 || num == 2 )
            numbersList.push_back(num);
    }

    // Sort the numbers in descending order
    sort(numbersList.begin(), numbersList.end(), greater<long long>());

    // Look for the largest prime numbers of interest
    int largestPrimes = 0;

    for ( long i = 0; i < numbersList.size() && largestPrimes < TOTAL_PRIMES; i++ ) {
        if ( isPrime(numbersList[i]) ) {
            cout << numbersList[i] << endl;
            largestPrimes++;
        }
    }

    // Close open resources
    numbersFile.close();

    return 0;
}
