/*
 * Copyright: STEM Loyola
 * Date     : April 2019
 * ID       : 19.04-A2
 * Level    : 2 (Intermediate)
 *
 * Task     : You are given a text file containing the 2018 Form Four results
 *            for Loyola. On each line: a student ID, gender and his/her NECTA
 *            points are given. Complete the provided program to count how many
 *            students got each of the points. That is, if available: how many
 *            students got 7 points, how many got 8 points, etc. As an example,
 *            below is the count of the last four points.
 *
 *                    25 points: 3 students
 *                    26 points: 3 students
 *                    29 points: 2 students
 *                    30 points: 1 student
 *
 *            Bonus points will be given if your program will also list the
 *            respective students as shown below.
 *
 *                    25 points: 3 students (S0800/0071, S0800/0089, S0800/0101)
 *                    26 points: 3 students (S0800/0003, S0800/0054, S0800/0115)
 *                    29 points: 2 students (S0800/0072, S0800/0118)
 *                    30 points: 1 student (S0800/0110)
 *
 *
 * Solved By: STEM Loyola Programming Team
*/

#include<iostream>  // std, cout, endl
#include<fstream>   // ifstream
#include<cstdlib>   // exit()
#include<map>

#define FILE_NAME "2018-CSEE-S0800.txt"

using namespace std;

int main() {
    // Open the numbers file
    ifstream resultsFile(FILE_NAME);

    // Ensure the file was opened successfully
    if ( resultsFile.is_open() == false ) {
        cout << "Error: could not open the file \"" << FILE_NAME << "\""
             << endl << "Quitting..." << endl;

        exit(1);    // Terminate the program
    }

    // Process the result's file
    string studentID;
    char gender;
    int points;

    map<int, int> freq;        // Tracks the frequency of each point
    map<int, string> students; // Tracks the students with a particular point

    while ( resultsFile >> studentID >> gender >> points ) {
        // Count a given point
        freq[points] = freq[points] + 1;

        // Include a given student in a list of a particular point
        if ( freq[points] > 1 ) students[points] += ", " + studentID;
        else students[points] = studentID;
    }

    // Display results
    for ( map<int, int>::iterator it = freq.begin(); it != freq.end(); it++ ) {
        if ( it->second > 1 ) {
            cout << it->first << " points: " << it->second
                 << " students (" << students[it->first] << ")" << endl;
        } else {
            cout << it->first << " points: " << it->second
                 << " student (" << students[it->first] << ")" << endl;
        }
    }

    // Close open resources
    resultsFile.close();

    return 0;
}
