/*
 * Copyright: STEM Loyola
 * Date     : April 2019
 * ID       : 19.04-A2
 * Level    : 2 (Intermediate)
 *
 * Task     : You are given a text file containing the 2018 Form Four results
 *            for Loyola. On eachline: a student ID, gender and his/her NECTA
 *            points are given. Complete the provided program to count how many
 *            students got each of the points. That is, if available: howmany 
 *            students got 7 points, how many got 8 points, etc. As an example,
 *            below is the count of the last four points.
 *            
 *                    25 points: 3 students
 *                    26 points: 3 students
 *                    29 points: 2 students
 *                    30 points: 1 student
 *           
 *            Bonus points will be given if your program will also list the
 *            respective students as shown below.   
 * 
 *                    25 points: 3 students (S0800/0071, S0800/0089, S0800/0101)
 *                    26 points: 3 students (S0800/0003, S0800/0054, S0800/0115)
 *                    29 points: 2 students (S0800/0072, S0800/0118)
 *                    30 points: 1 student (S0800/0110)
 *
 * 
 * Solved By: <Full Name> - <Email Address>
 *     Class: <Form> - <Stream/Combination>
*/

import java.io.File;
import java.util.Scanner;

class STEMChallenge02 {
    
    static final String FILE_NAME  = "2018-CSEE-S0800.txt";
    
    public static void main(String args[]) {
        // Open the results file and ensure it was opened successfully
        Scanner resultsScanner = null;

        try {
            resultsScanner = new Scanner(new File(FILE_NAME));

        } catch (Exception e) {
            System.err.format("Error: could not open the file \"%s\"\n", FILE_NAME);
            System.err.format("Quitting...\n");

            System.exit(1);    // Terminate the program
        }

        // Process the result's file
        String studentID;
        char gender;
        int points;

        while(resultsScanner.hasNextLine()){
            studentID = resultsScanner.next();
            gender = resultsScanner.next().charAt(0);
            points = resultsScanner.nextInt();

            System.out.printf("%s %s %d\n", studentID, gender, points);
        }

        // Close open resources
        resultsScanner.close();
    }
}
